/* GiganticPrints — main.js */
(function () {
  'use strict';

  // Categories dropdown toggle (fallback nav)
  document.querySelectorAll('[data-dropdown]').forEach(function (dd) {
    var trigger = dd.querySelector('.nav-link');
    if (!trigger) return;

    var close = function () { dd.setAttribute('aria-expanded', 'false'); };
    var open  = function () { dd.setAttribute('aria-expanded', 'true'); };

    trigger.addEventListener('click', function (e) {
      e.stopPropagation();
      dd.getAttribute('aria-expanded') === 'true' ? close() : open();
    });

    dd.querySelectorAll('.nav-dropdown-item, .nav-dropdown-footer').forEach(function (item) {
      item.addEventListener('click', function () { setTimeout(close, 80); });
    });

    document.addEventListener('click', function (e) {
      if (!dd.contains(e.target)) close();
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') close();
    });
  });

  // Smooth scroll for in-page anchors
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var id = a.getAttribute('href');
      if (id.length > 1 && document.querySelector(id)) {
        e.preventDefault();
        document.querySelector(id).scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // Product & Item card behaviour:
  //   Desktop (hover:hover): CSS handles image swap / CTA reveal.
  //   Touch: first tap reveals, second tap navigates, auto-collapse 5s.
  var hasHover = window.matchMedia('(hover: hover)').matches;

  document.querySelectorAll('.product-card, .item-card').forEach(function (card) {
    card.addEventListener('click', function (e) {
      if (hasHover) {
        // Desktop — let the href navigate naturally (don't prevent default)
        return;
      }
      if (!card.classList.contains('is-revealed')) {
        e.preventDefault();
        document.querySelectorAll('.product-card.is-revealed, .item-card.is-revealed').forEach(function (c) {
          if (c !== card) c.classList.remove('is-revealed');
        });
        card.classList.add('is-revealed');
        clearTimeout(card._collapse);
        card._collapse = setTimeout(function () { card.classList.remove('is-revealed'); }, 5000);
      }
      // Second tap: allow navigation (do not prevent default)
    });
  });

  // Update cart badge via WooCommerce fragments (AJAX)
  document.body.addEventListener('wc_fragments_refreshed', function () {
    var count = typeof wc_cart_fragments_params !== 'undefined'
      ? (window.cartItemCount || 0) : 0;
    document.querySelectorAll('.nbd-icon-btn .badge').forEach(function (b) {
      if (count > 0) { b.textContent = count; b.style.display = ''; }
      else           { b.style.display = 'none'; }
    });
  });

})();
