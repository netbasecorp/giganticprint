﻿<?php
/**
 * woocommerce.php — wrapper for all WooCommerce pages (shop, category, single product, cart, checkout, account).
 * WooCommerce checks for this file first; if found it uses it instead of index.php.
 */
get_header(); ?>

<main class="site-main woo-page">
  <?php do_action( 'giga_before_content' ); ?>

  <?php
  // Page title block (WooCommerce suppresses its own via filter in functions.php)
  $page_title = '';
  if ( is_shop() ) {
    $page_title = get_the_title( wc_get_page_id( 'shop' ) );
  } elseif ( is_product_category() ) {
    $page_title = single_cat_title( '', false );
  } elseif ( is_product_tag() ) {
    $page_title = single_tag_title( '', false );
  } elseif ( is_product() ) {
    $page_title = get_the_title();
  } elseif ( is_cart() ) {
    $page_title = __( 'Cart', 'storecmsmart' );
  } elseif ( is_checkout() ) {
    $page_title = __( 'Checkout', 'storecmsmart' );
  } elseif ( is_account_page() ) {
    $page_title = __( 'My Account', 'storecmsmart' );
  }
  if ( $page_title ) : ?>
    <div class="page-hero">
      <div class="container">
        <h1 class="page-title"><?php echo esc_html( $page_title ); ?></h1>
        <?php if ( is_product_category() ) : ?>
          <p class="page-subtitle"><?php echo wp_kses_post( category_description() ); ?></p>
        <?php endif; ?>
      </div>
    </div>
  <?php endif; ?>

  <div class="container woo-page-container">
    <?php woocommerce_content(); ?>
  </div>
</main>

<?php get_footer(); ?>
